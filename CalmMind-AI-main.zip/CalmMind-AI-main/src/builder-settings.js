import { builder } from '@builder.io/react';

builder.init(import.meta.env.VITE_PUBLIC_BUILDER_KEY); // Replace with your public API key
