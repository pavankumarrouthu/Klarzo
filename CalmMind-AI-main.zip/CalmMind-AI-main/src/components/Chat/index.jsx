import ChatInterface from "./ChatInterface";

export { ChatInterface };
export default ChatInterface;
